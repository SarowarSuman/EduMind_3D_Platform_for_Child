<div align="center">

<img src="docs/assets/banner.svg" alt="EduMind — AI 3D Classroom" width="100%">

<em>Illustrated preview — the project has no live screenshot yet. See <a href="#-add-your-own-screenshots">Add your own screenshots</a> below.</em>

<br><br>

![Made with Three.js](https://img.shields.io/badge/3D-Three.js-black?style=flat-square)
![Powered by Gemini](https://img.shields.io/badge/AI-Google%20Gemini-4285F4?style=flat-square)
![No backend](https://img.shields.io/badge/backend-none%20needed-success?style=flat-square)
![Free to run](https://img.shields.io/badge/cost-100%25%20free-FFC857?style=flat-square&labelColor=2a4d37)
![Language](https://img.shields.io/badge/UI-বাংলা%20%2B%20English-7c3aed?style=flat-square)

</div>

# EduMind — AI 3D Classroom

একটা ব্রাউজার-ভিত্তিক, বাংলা-প্রথম 3D ক্লাসরুম যেখানে বাচ্চারা কথা বলে বা লিখে প্রশ্ন করে, একটা animated 3D শিক্ষক কথা বলে উত্তর দেয়, আর উত্তরের সাথে সাথে ব্ল্যাকবোর্ডে ডায়াগ্রাম ফুটে ওঠে। পুরোটাই একটা **একক HTML ফাইল** — কোনো সার্ভার, কোনো ইনস্টলেশন, কোনো বিল্ড স্টেপ ছাড়াই চলে।

> **এক লাইনে:** Three.js দিয়ে বানানো 3D ক্লাসরুম + Google Gemini-এর ফ্রি API + ব্রাউজারের ভয়েস ফিচার — সব মিলিয়ে একটা মজার, খরচহীন AI শিক্ষক।

---

## ✨ Features

| | |
|---|---|
| 🏫 **পুরো 3D ক্লাসরুম** | ডেস্ক, চেয়ার, গ্লোব, দেয়াল ঘড়ি, কর্কবোর্ড, জানালা দিয়ে আলো — সব Three.js দিয়ে কোড থেকে বানানো, কোনো বাইরের 3D মডেল ফাইল লাগে না |
| 👩‍🏫 **৩টা বদলানো যায় এমন 3D শিক্ষক** | Queen, Abubokkor, Rupa — প্রতিটা আলাদা চেহারা, পোশাক, আর কথা বলার সময় মুখ নড়ে |
| 🎤 **ভয়েসে প্রশ্ন, ভয়েসে উত্তর** | Web Speech API দিয়ে — বলো, শিক্ষক গলায় উত্তর দেবে। "Conversation mode" চালু থাকলে উত্তর শেষে নিজে থেকেই আবার শুনতে শুরু করে |
| ✏️ **লাইভ চক-বোর্ড** | প্রতিটা উত্তরের সাথে বোর্ডে টাইটেল + পয়েন্ট ফুটে ওঠে, ঠিক যেন সত্যিকারের শিক্ষক লিখছে |
| 🎯 **কুইজ মোড** | শেখার পর নিজেকে যাচাই করার জন্য ছোট কুইজ |
| 🔥 **গেমিফিকেশন** | Gems, শেখা Topics-এর সংখ্যা, আর দৈনিক Streak — ব্রাউজারেই সেভ থাকে (localStorage) |
| 🌐 **বাংলা ⇄ English** | এক ট্যাপে ভাষা বদলানো যায়, UI আর কণ্ঠ দুটোই |
| 🧠 **Smart model fallback** | একটা Gemini মডেল ব্যস্ত/ডাউন থাকলে অটোমেটিক পরেরটায় চলে যায় (৫টা মডেলের ফলব্যাক চেইন) |
| 💸 **সম্পূর্ণ ফ্রি, সার্ভার ছাড়া** | নিজের ফ্রি Gemini API key ব্রাউজারেই বসাও — কোনো backend, কোনো hosting bill লাগে না |

---

## 🖼️ Preview

<img src="docs/assets/feature-strip.svg" alt="Live chalkboard, quiz mode, and teacher swap preview" width="100%">

<sub>এই ছবিগুলো প্রকৃত UI-এর রঙ ও স্টাইল মিলিয়ে বানানো ইলাস্ট্রেশন, সরাসরি স্ক্রিনশট না।</sub>

---

## 🚀 Quick Start

### ১) ফ্রি API key বানাও (২ মিনিট)
1. [aistudio.google.com](https://aistudio.google.com/) এ যাও, Google অ্যাকাউন্ট দিয়ে লগইন করো
2. **"Get API key"** → **"Create API key"** চাপো
3. `AIza...` দিয়ে শুরু হওয়া key-টা কপি করে রাখো

### ২) চালাও

**সবচেয়ে সহজ — সরাসরি খোলো:**
এই রিপোর ফাইলটা (`index.html`) ডাবল-ক্লিক করে ব্রাউজারে খোলো। ইনস্টলেশন কিচ্ছু লাগবে না।

**অথবা GitHub Pages দিয়ে অনলাইনে হোস্ট করো:**
1. এই রিপো GitHub-এ পুশ করো, মূল ফাইলের নাম `index.html` রাখো
2. Settings → Pages → Branch হিসেবে `main` সিলেক্ট করো → Save
3. কিছুক্ষণ পর `https://<তোমার-ইউজারনেম>.github.io/<রিপোর-নাম>/` এ লাইভ হয়ে যাবে

### ৩) প্রথমবার খোলার পর
1. উপরে ⚙️ (Settings) বাটনে চাপো
2. নিজের Gemini API key পেস্ট করো → **"Save + Test"**
3. সবুজ ✅ দেখলেই রেডি — এবার 🎤 চেপে বা লিখে প্রশ্ন করো!

> **নোট:** Key শুধু তোমার নিজের ব্রাউজারে (localStorage) সেভ থাকে — কোনো সার্ভারে পাঠানো হয় না। প্রতিটা ব্যবহারকারীকে নিজের key নিজে বসাতে হবে।

---

## 🧠 How it works

```mermaid
flowchart LR
    U["🧑‍🎓 বাচ্চা<br>(ভয়েস বা টেক্সট)"] --> B["🌐 Browser<br>Three.js 3D scene"]
    B -- "Web Speech API" --> B
    B -- "fetch() নিজের API key দিয়ে" --> G["✨ Google Gemini<br>(ফ্রি tier)"]
    G -- "উত্তর + বোর্ড ডেটা" --> B
    B --> T["🗣️ 3D শিক্ষক<br>(কথা বলে, মুখ নড়ে)"]
    B --> C["✏️ চক-বোর্ড ক্যানভাস"]
    B --> L["💾 localStorage<br>(gems · streak · পছন্দের শিক্ষক)"]
```

পুরো অ্যাপটা ব্রাউজারের ভেতরেই চলে — কোনো backend সার্ভার নেই। শুধু Gemini-কে প্রশ্ন পাঠানোর সময় ব্রাউজার থেকে সরাসরি Google-এর API-তে কল যায়, তোমার নিজের key দিয়ে।

---

## 🔊 ভয়েস নিয়ে কিছু কথা

- ভয়েস ইনপুট/আউটপুট সবচেয়ে ভালো কাজ করে **Google Chrome**-এ (Web Speech API-র সাপোর্ট browser-ভেদে আলাদা)
- মাইক্রোফোন পারমিশন চাইবে প্রথমবার — অনুমতি দিতে হবে
- বাংলা কণ্ঠ ব্রাউজার আর অপারেটিং সিস্টেম অনুযায়ী ভিন্ন শোনাতে পারে; কিছু ডিভাইসে প্রাকৃতিক বাংলা voice না-ও থাকতে পারে

---

## 🗂️ Project structure

```
.
├── index.html            ← পুরো অ্যাপ (HTML + CSS + JS, একটাই ফাইল)
└── docs/
    └── assets/
        ├── banner.svg         ← README হিরো ইমেজ
        └── feature-strip.svg  ← README প্রিভিউ ইমেজ
```

কোনো `package.json`, `node_modules`, বা বিল্ড স্টেপ নেই — একটাই স্ট্যাটিক ফাইল, যেকোনো স্ট্যাটিক হোস্টে (GitHub Pages, Netlify, Vercel, বা শুধু নিজের কম্পিউটারে) চলবে।

---

## 🧩 নিজের মতো বদলানো যায় যেসব জায়গা

<details>
<summary><strong>নতুন শিক্ষক যোগ করা</strong></summary>

<br>

কোডে `PRESETS` অ্যারেতে নতুন একটা অবজেক্ট যোগ করো — নাম, গায়ের রঙ, স্যুট/পোশাকের রঙ, চুলের রঙ ঠিক করে দিলেই নতুন 3D শিক্ষক তৈরি হয়ে যাবে।

</details>

<details>
<summary><strong>আরো Gemini মডেল fallback-এ যোগ করা</strong></summary>

<br>

`GEMINI_MODELS` অ্যারেতে মডেলের নাম যোগ/বাদ দিয়ে fallback চেইন সাজানো যায় — প্রথমটা ব্যস্ত থাকলে পরেরটা ট্রাই হবে।

</details>

<details>
<summary><strong>শিক্ষকের ব্যক্তিত্ব/টোন বদলানো</strong></summary>

<br>

সিস্টেম প্রম্পট (যেটা `sysPrompt()`-এর ভেতরে আছে) এডিট করে শিক্ষকের কথা বলার ধরন, বয়সের লেভেল, বা বিষয়ভিত্তিক ফোকাস বদলানো যায়।

</details>

---

## 🔒 Privacy & খরচ

- তোমার Gemini API key শুধু **তোমার নিজের ব্রাউজারে** (localStorage) থাকে — কোনো সার্ভারে যায় না, এই রিপোতেও সেভ হয় না
- প্রতিটা প্রশ্ন সরাসরি ব্রাউজার থেকে Google-এর API-তে যায়; শেখার progress (gems/streak) শুধু তোমার ডিভাইসে থাকে
- Google-এর ফ্রি tier-এ একটা নির্দিষ্ট সীমা পর্যন্ত ব্যবহার ফ্রি — সীমা ছাড়িয়ে গেলে Google Cloud কনসোলে বিলিং সেটআপ লাগতে পারে (দেখো [ai.google.dev/pricing](https://ai.google.dev/pricing))
- **Public রিপোতে কখনো নিজের আসল API key কমিট কোরো না** — key সবসময় Settings প্যানেল থেকে ব্রাউজারে বসাও, কোডে হার্ডকোড কোরো না

---

## 📸 Add your own screenshots

এই README-এর ছবিগুলো আসল স্ক্রিনশট না, বানানো ইলাস্ট্রেশন। আসল স্ক্রিনশট/রেকর্ডিং যোগ করতে:

1. অ্যাপটা ব্রাউজারে খুলে একটা স্ক্রিনশট নাও
2. GitHub-এ এই `README.md` ফাইলটা এডিট মোডে খোলো, ছবিটা টেনে এনে (drag & drop) ছেড়ে দাও — GitHub নিজে থেকেই আপলোড করে একটা লিংক বসিয়ে দেবে
3. ওই লিংকটা দিয়ে উপরের `docs/assets/banner.svg` রেফারেন্সটা বদলে দাও, অথবা নতুন একটা "📸 Screenshots" সেকশন যোগ করো

---

## 🤝 Contributing

ছোট প্রজেক্ট, pull request স্বাগতম — বিশেষ করে: নতুন বিষয়ের জন্য প্রম্পট টেমপ্লেট, নতুন ভাষা সাপোর্ট, নতুন শিক্ষক প্রিসেট, বা accessibility উন্নতি।

## 📄 License

এই রিপোতে এখনো কোনো license ফাইল নেই। পাবলিক শেয়ার করার আগে একটা license যোগ করার পরামর্শ থাকলো (ওপেন-সোর্স প্রজেক্টের জন্য [MIT](https://choosealicense.com/licenses/mit/) একটা সাধারণ, সহজ পছন্দ)।

---

<div align="center">
<sub>Built for kids who'd rather learn than scroll. 🎒✨</sub>
</div>
